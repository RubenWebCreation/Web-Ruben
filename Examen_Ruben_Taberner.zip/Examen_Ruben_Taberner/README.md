Al principio utilicé los apuntes y ejercicios hechos en clase. Luego comencé a
usar Copilot para agilizar mi código ya que suelo añadir más de lo que se
necesita. El resultado fue bastante bueno y me parece que cumple con lo pedido
en el examen. Admito que se me da mal expresarme en algunos ejercicios. Una
disculpa por eso.

**Ejercicio 1:** Apuntes de 09-Funciones, 13-DOM, 05-Condicionales. También
utilicé de referencia el apunte de Las Películas cambiando los nombres y las
variables.

**Ejercicio 2:** Utilicé los apuntes recientes y le pedí a Copilot cómo agregar
CSS a mi proyecto JS ya que tenía un poco de dudas y por eso utilicé la IA.

**Ejercicio 3:** Modifiqué mi código del Ejercicio 1 además de mejorar,
guiándome con Copilot, el sistema de libro leído y no. Lo demás fue agregar la
imagen que investigué en MDN.

**Ejercicio 4:** Siendo sincero, tuve que mirar cómo incluir mi código de libros
a un JSON. Tuve que eliminar comas y muchas cosas para que no saltaran errores.
Luego emparejé el archivo pero seguía habiendo errores, a lo que llamé a mi
profesor y él vio el problema: no había puesto bien el enlace al JSON.

Ejercicio 5: Siguiendo Los Apuntes de DOM y con la Herramienta Copailot
